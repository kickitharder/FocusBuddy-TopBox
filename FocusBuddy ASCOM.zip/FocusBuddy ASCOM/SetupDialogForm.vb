Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports System.IO.Ports
Imports ASCOM.Utilities
Imports System.Math

<ComVisible(False)>
Public Class SetupDialogForm
    Dim serialError As Boolean = True
    Dim resp(25) As String

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click ' OK button event handler
        ' Persist new values of user settings to the ASCOM profile
        ' Update the state variables with results from the dialogue

        Focuser.absoluteMode = radAbsolute.Checked
        Focuser.powerDetect = chkPowerDetect.Checked
        If rad10ths.Checked = True Then Focuser.resolution = 100
        If rad100ths.Checked = True Then Focuser.resolution = 10
        If rad1000ths.Checked = True Then Focuser.resolution = 1
        Focuser.traceState = chkTrace.Checked
        Focuser.comPort = ComboBoxComPort.SelectedItem
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click 'Cancel button event handler
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub ShowAscomWebPage(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.DoubleClick, PictureBox1.Click
        ' Click on ASCOM logo event handler
        Try
            System.Diagnostics.Process.Start("http://ascom-standards.org/")
        Catch noBrowser As System.ComponentModel.Win32Exception
            If noBrowser.ErrorCode = -2147467259 Then
                MessageBox.Show(noBrowser.Message)
            End If
        Catch other As System.Exception
            MessageBox.Show(other.Message)
        End Try
    End Sub

    Private Sub pbxCMHASD_Click(sender As Object, e As EventArgs) Handles pbxCMHASD.Click
        Try
            System.Diagnostics.Process.Start("http://www.crayfordmanorastro.com/")
        Catch noBrowser As System.ComponentModel.Win32Exception
            If noBrowser.ErrorCode = -2147467259 Then
                MessageBox.Show(noBrowser.Message)
            End If
        Catch other As System.Exception
            MessageBox.Show(other.Message)
        End Try
    End Sub

    Private Sub SetupDialogForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load ' Form load event handler
        ' Retrieve current values of user settings from the ASCOM Profile
        Me.TopMost = True
        Me.TopMost = False
        InitUI()
    End Sub

    Private Sub InitUI()
        chkPowerDetect.Checked = Focuser.powerDetect
        chkTrace.Checked = Focuser.traceState
        If Focuser.absoluteMode Then
            radAbsolute.Checked = True
        Else
            radRelative.Checked = True
        End If
        If Focuser.resolution = 1 Then rad1000ths.Checked = True
        If Focuser.resolution = 10 Then rad100ths.Checked = True
        If Focuser.resolution = 100 Then rad10ths.Checked = True

        ComboBoxComPort.Items.Clear()
        ComboBoxComPort.Items.AddRange(System.IO.Ports.SerialPort.GetPortNames())       ' use System.IO because it's static
        Dim listLength As Integer = ComboBoxComPort.Items.Count - 1                     ' Sort COM ports in number order
        Dim list(listLength) As Integer
        For i = 0 To listLength
            list(i) = Str(Mid(ComboBoxComPort.Items(i), 4, 3))
        Next
        Array.Sort(list)
        ComboBoxComPort.Items.Clear()
        For i = 0 To listLength
            ComboBoxComPort.Items.Add("COM" + list(i).ToString)
        Next

        ' select the current port if possible
        If ComboBoxComPort.Items.Contains(Focuser.comPort) Then
            ComboBoxComPort.SelectedItem = Focuser.comPort
        End If
    End Sub
    Private Function SerialCmd(cmdStr As String) As String
        If serialError Then Return ""
        Dim retStr As String = ""
        Dim objSerial As New SerialPort
        cmdStr += vbCrLf

        Try
            With objSerial
                .PortName = ComboBoxComPort.SelectedItem.ToString
                .BaudRate = 9600
                .ReadTimeout = 1000
                .WriteTimeout = 1000
                .Open()
                .Write(cmdStr)
            End With
            retStr = objSerial.ReadTo(vbCrLf)
        Catch ex As Exception
            lstDetails.Items.Clear()
            lstDetails.Items.Add("FocusBuddy driver is unable to open " + objSerial.PortName)
            retStr = ""
            serialError = True
        End Try

        Try
            objSerial.Close()
        Catch ex As Exception
        End Try

        Return retStr

    End Function
    Private Sub btnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click
        Dim respStr As String = ""
        Dim powerStr As String
        Dim positionStr As String
        Dim i As Integer
        serialError = False
        lstDetails.Items.Clear()
        For i = 1 To 10
            respStr = SerialCmd("V")
            If serialError = 1 Then Exit Sub
        Next
        powerStr = "Focuser power: " + IIf(SerialCmd("~") = "1", "ON", "OFF")
        positionStr = "Position: " + SerialCmd("P")
        If respStr.StartsWith("FocusBuddy") Then
            lstDetails.Items.Add(respStr)
            lstDetails.Items.Add("FocusBuddy is OK")
            lstDetails.Items.Add(powerStr)
            lstDetails.Items.Add(positionStr)
        Else
            lstDetails.Items.Add("FocusBuddy not responding - check connection")
        End If

    End Sub

End Class
