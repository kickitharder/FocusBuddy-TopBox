<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SetupDialogForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SetupDialogForm))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.chkTrace = New System.Windows.Forms.CheckBox()
        Me.ComboBoxComPort = New System.Windows.Forms.ComboBox()
        Me.btnCheck = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.lstDetails = New System.Windows.Forms.ListBox()
        Me.grpMode = New System.Windows.Forms.GroupBox()
        Me.radRelative = New System.Windows.Forms.RadioButton()
        Me.radAbsolute = New System.Windows.Forms.RadioButton()
        Me.pbxCMHASD = New System.Windows.Forms.PictureBox()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.chkPowerDetect = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rad1000ths = New System.Windows.Forms.RadioButton()
        Me.rad100ths = New System.Windows.Forms.RadioButton()
        Me.rad10ths = New System.Windows.Forms.RadioButton()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpMode.SuspendLayout()
        CType(Me.pbxCMHASD, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(7, 242)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(48, 56)
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'chkTrace
        '
        Me.chkTrace.AutoSize = True
        Me.chkTrace.Location = New System.Drawing.Point(169, 234)
        Me.chkTrace.Name = "chkTrace"
        Me.chkTrace.Size = New System.Drawing.Size(69, 17)
        Me.chkTrace.TabIndex = 8
        Me.chkTrace.Text = "Trace on"
        Me.chkTrace.UseVisualStyleBackColor = True
        '
        'ComboBoxComPort
        '
        Me.ComboBoxComPort.FormattingEnabled = True
        Me.ComboBoxComPort.Location = New System.Drawing.Point(95, 42)
        Me.ComboBoxComPort.Name = "ComboBoxComPort"
        Me.ComboBoxComPort.Size = New System.Drawing.Size(84, 21)
        Me.ComboBoxComPort.TabIndex = 9
        '
        'btnCheck
        '
        Me.btnCheck.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCheck.Location = New System.Drawing.Point(195, 41)
        Me.btnCheck.Name = "btnCheck"
        Me.btnCheck.Size = New System.Drawing.Size(63, 23)
        Me.btnCheck.TabIndex = 19
        Me.btnCheck.Text = "Check"
        Me.btnCheck.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Comic Sans MS", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(-1, 2)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(147, 34)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "FocusBuddy"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(4, 46)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(85, 13)
        Me.label2.TabIndex = 21
        Me.label2.Text = "Select COM port"
        '
        'lstDetails
        '
        Me.lstDetails.FormattingEnabled = True
        Me.lstDetails.Location = New System.Drawing.Point(7, 79)
        Me.lstDetails.Name = "lstDetails"
        Me.lstDetails.Size = New System.Drawing.Size(310, 56)
        Me.lstDetails.TabIndex = 22
        '
        'grpMode
        '
        Me.grpMode.Controls.Add(Me.radRelative)
        Me.grpMode.Controls.Add(Me.radAbsolute)
        Me.grpMode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpMode.Location = New System.Drawing.Point(163, 141)
        Me.grpMode.Name = "grpMode"
        Me.grpMode.Size = New System.Drawing.Size(140, 66)
        Me.grpMode.TabIndex = 23
        Me.grpMode.TabStop = False
        Me.grpMode.Text = "Focuser Mode"
        '
        'radRelative
        '
        Me.radRelative.AutoSize = True
        Me.radRelative.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radRelative.Location = New System.Drawing.Point(6, 17)
        Me.radRelative.Name = "radRelative"
        Me.radRelative.Size = New System.Drawing.Size(64, 17)
        Me.radRelative.TabIndex = 10
        Me.radRelative.TabStop = True
        Me.radRelative.Text = "Relative"
        Me.radRelative.UseVisualStyleBackColor = True
        '
        'radAbsolute
        '
        Me.radAbsolute.AutoSize = True
        Me.radAbsolute.Checked = True
        Me.radAbsolute.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radAbsolute.Location = New System.Drawing.Point(6, 40)
        Me.radAbsolute.Name = "radAbsolute"
        Me.radAbsolute.Size = New System.Drawing.Size(66, 17)
        Me.radAbsolute.TabIndex = 11
        Me.radAbsolute.TabStop = True
        Me.radAbsolute.Text = "Absolute"
        Me.radAbsolute.UseVisualStyleBackColor = True
        '
        'pbxCMHASD
        '
        Me.pbxCMHASD.Image = CType(resources.GetObject("pbxCMHASD.Image"), System.Drawing.Image)
        Me.pbxCMHASD.Location = New System.Drawing.Point(61, 242)
        Me.pbxCMHASD.Name = "pbxCMHASD"
        Me.pbxCMHASD.Size = New System.Drawing.Size(61, 56)
        Me.pbxCMHASD.TabIndex = 79
        Me.pbxCMHASD.TabStop = False
        '
        'OK_Button
        '
        Me.OK_Button.Location = New System.Drawing.Point(163, 275)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(236, 275)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(203, 2)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(100, 13)
        Me.Label25.TabIndex = 26
        Me.Label25.Text = "Version: V0.211029"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'chkPowerDetect
        '
        Me.chkPowerDetect.AutoSize = True
        Me.chkPowerDetect.Location = New System.Drawing.Point(169, 211)
        Me.chkPowerDetect.Name = "chkPowerDetect"
        Me.chkPowerDetect.Size = New System.Drawing.Size(143, 17)
        Me.chkPowerDetect.TabIndex = 80
        Me.chkPowerDetect.Text = "Detect power for focuser"
        Me.chkPowerDetect.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rad1000ths)
        Me.GroupBox1.Controls.Add(Me.rad100ths)
        Me.GroupBox1.Controls.Add(Me.rad10ths)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(7, 141)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(140, 95)
        Me.GroupBox1.TabIndex = 81
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Resolution"
        '
        'rad1000ths
        '
        Me.rad1000ths.AutoSize = True
        Me.rad1000ths.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad1000ths.Location = New System.Drawing.Point(7, 68)
        Me.rad1000ths.Name = "rad1000ths"
        Me.rad1000ths.Size = New System.Drawing.Size(63, 17)
        Me.rad1000ths.TabIndex = 2
        Me.rad1000ths.Text = "1000ths"
        Me.rad1000ths.UseVisualStyleBackColor = True
        '
        'rad100ths
        '
        Me.rad100ths.AutoSize = True
        Me.rad100ths.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad100ths.Location = New System.Drawing.Point(7, 43)
        Me.rad100ths.Name = "rad100ths"
        Me.rad100ths.Size = New System.Drawing.Size(57, 17)
        Me.rad100ths.TabIndex = 1
        Me.rad100ths.Text = "100ths"
        Me.rad100ths.UseVisualStyleBackColor = True
        '
        'rad10ths
        '
        Me.rad10ths.AutoSize = True
        Me.rad10ths.Checked = True
        Me.rad10ths.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad10ths.Location = New System.Drawing.Point(7, 20)
        Me.rad10ths.Name = "rad10ths"
        Me.rad10ths.Size = New System.Drawing.Size(51, 17)
        Me.rad10ths.TabIndex = 0
        Me.rad10ths.TabStop = True
        Me.rad10ths.Text = "10ths"
        Me.rad10ths.UseVisualStyleBackColor = True
        '
        'SetupDialogForm
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(326, 306)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.chkPowerDetect)
        Me.Controls.Add(Me.Cancel_Button)
        Me.Controls.Add(Me.pbxCMHASD)
        Me.Controls.Add(Me.OK_Button)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.grpMode)
        Me.Controls.Add(Me.lstDetails)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnCheck)
        Me.Controls.Add(Me.ComboBoxComPort)
        Me.Controls.Add(Me.chkTrace)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "SetupDialogForm"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FocusBuddy Setup"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpMode.ResumeLayout(False)
        Me.grpMode.PerformLayout()
        CType(Me.pbxCMHASD, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents chkTrace As System.Windows.Forms.CheckBox
    Friend WithEvents ComboBoxComPort As System.Windows.Forms.ComboBox
    Friend WithEvents btnCheck As Button
    Friend WithEvents Label1 As Label
    Private WithEvents label2 As Label
    Friend WithEvents lstDetails As ListBox
    Friend WithEvents grpMode As GroupBox
    Friend WithEvents radRelative As RadioButton
    Friend WithEvents radAbsolute As RadioButton
    Friend WithEvents pbxCMHASD As PictureBox
    Friend WithEvents OK_Button As Button
    Friend WithEvents Cancel_Button As Button
    Friend WithEvents Label25 As Label
    Friend WithEvents chkPowerDetect As CheckBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rad1000ths As RadioButton
    Friend WithEvents rad100ths As RadioButton
    Friend WithEvents rad10ths As RadioButton
End Class
